# Jobs para coleta automática de dados

