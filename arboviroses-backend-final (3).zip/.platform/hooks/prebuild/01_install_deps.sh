#!/bin/bash

# Atualiza o pip e instala dependências
sudo pip install --upgrade pip
sudo pip install -r requirements.txt